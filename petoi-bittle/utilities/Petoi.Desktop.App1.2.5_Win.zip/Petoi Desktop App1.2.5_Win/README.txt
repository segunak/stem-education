**Windows users:**
Double-click the exe file to run the app. Keep all the files in the Win folder when moving the app. 

For more details, please refer to: https://docs.petoi.com/desktop-app/introduction
